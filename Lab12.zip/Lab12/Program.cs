﻿using System;
using System.Threading;

// Define the AlarmEventArgs class to pass event data
public class AlarmEventArgs : EventArgs
{
    public string Message { get; set; }
}

// Publisher class
public class AlarmClock
{
    // Define the event using EventHandler<T>
    public event EventHandler<AlarmEventArgs> AlarmRaised;

    private TimeSpan targetTime;

    public void SetAlarm(string timeInput)
    {
        if (TimeSpan.TryParse(timeInput, out targetTime))
        {
            Console.WriteLine($"Alarm set for {targetTime}");
            StartMonitoring();
        }
        else
        {
            Console.WriteLine("Invalid time format. Please use HH:MM:SS");
        }
    }

    private void StartMonitoring()
    {
        while (true)
        {
            TimeSpan currentTime = DateTime.Now.TimeOfDay;

            // Check if current time matches target time (within 1 second tolerance)
            if (Math.Abs((currentTime - targetTime).TotalSeconds) < 1)
            {
                OnAlarmRaised("Wake up! Alarm time reached!");
                break;
            }

            Thread.Sleep(1000); // Check every second
        }
    }

    protected virtual void OnAlarmRaised(string message)
    {
        AlarmRaised?.Invoke(this, new AlarmEventArgs { Message = message });
    }
}

// Subscriber class
public class AlarmSubscriber
{
    public void RingAlarm(object sender, AlarmEventArgs e)
    {
        Console.WriteLine($"ALARM: {e.Message}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter alarm time in HH:MM:SS format:");
        string timeInput = Console.ReadLine();

        var alarmClock = new AlarmClock();
        var subscriber = new AlarmSubscriber();

        // Subscribe to the event
        alarmClock.AlarmRaised += subscriber.RingAlarm;

        alarmClock.SetAlarm(timeInput);

        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}