using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace AlarmClockWinForms
{
    public partial class Form1 : Form
    {
        private TimeSpan alarmTime;
        private System.Windows.Forms.Timer timer;  // Explicitly using Windows Forms Timer
        private Random random = new Random();
        private bool isAlarmRinging = false;
        private Color[] flashColors = { Color.Red, Color.Orange, Color.Yellow };
        private int colorIndex = 0;

        public Form1()
        {
            InitializeComponent();
            SetupTimer();
            SetupUI();
        }

        private void SetupUI()
        {
            // Form styling
            this.Text = "Alarm Clock";
            this.ClientSize = new Size(300, 220);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Current time display
            currentTimeLabel.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            currentTimeLabel.Text = $"Current: {DateTime.Now:HH:mm:ss}";
            currentTimeLabel.Location = new Point(20, 80);
            currentTimeLabel.AutoSize = true;

            // Status label
            statusLabel.Font = new Font("Segoe UI", 9);
            statusLabel.Text = "Ready to set alarm";
            statusLabel.Location = new Point(20, 160);
            statusLabel.AutoSize = true;

            // Start button styling
            startButton.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            startButton.Size = new Size(100, 35);
            startButton.Location = new Point(40, 120);
            startButton.Text = "Start Alarm";

            // Stop button styling
            stopButton.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            stopButton.Size = new Size(100, 35);
            stopButton.Location = new Point(160, 120);
            stopButton.Text = "Stop";
            stopButton.Enabled = false;
        }

        private void SetupTimer()
        {
            timer = new System.Windows.Forms.Timer(); // Explicitly using WinForms Timer
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (TimeSpan.TryParse(alarmTimeTextBox.Text, out alarmTime))
            {
                TimeSpan currentTime = DateTime.Now.TimeOfDay;

                if (alarmTime <= currentTime)
                {
                    MessageBox.Show("Please enter a future time.", "Invalid Time",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                isAlarmRinging = false;
                startButton.Enabled = false;
                stopButton.Enabled = true;
                statusLabel.Text = $"Alarm set for {alarmTime:hh\\:mm\\:ss}";
                statusLabel.ForeColor = Color.DarkGreen;
            }
            else
            {
                MessageBox.Show("Invalid time format. Please use HH:MM:SS", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer.Stop();
            isAlarmRinging = false;
            this.BackColor = SystemColors.Control;
            startButton.Enabled = true;
            stopButton.Enabled = false;
            statusLabel.Text = "Alarm stopped";
            statusLabel.ForeColor = Color.DarkRed;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            currentTimeLabel.Text = $"Current: {DateTime.Now:HH:mm:ss}";

            if (isAlarmRinging)
            {
                this.BackColor = flashColors[colorIndex];
                colorIndex = (colorIndex + 1) % flashColors.Length;
                return;
            }

            TimeSpan currentTime = DateTime.Now.TimeOfDay;
            if (Math.Abs((currentTime - alarmTime).TotalSeconds) < 1)
            {
                TriggerAlarm();
            }
        }

        private void TriggerAlarm()
        {
            isAlarmRinging = true;
            SystemSounds.Exclamation.Play(); // Use system sound
            statusLabel.Text = "ALARM RINGING!";
            statusLabel.ForeColor = Color.Red;
        }
    }
}
